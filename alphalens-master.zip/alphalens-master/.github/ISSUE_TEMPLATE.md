## Problem Description

**Please provide a minimal, self-contained, and reproducible example:**
```python
[Paste code here]
```

**Please provide the full traceback:**
```python
[Paste traceback here]
```

**Please provide any additional information below:**


## Versions

* Alphalens version: 
* Python version: 
* Pandas version: 
* Matplotlib version: 
