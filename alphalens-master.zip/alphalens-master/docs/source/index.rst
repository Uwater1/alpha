.. include:: ../../README.rst

API
---

Information on a specific functions, classes, or methods.

- :mod:`alphalens.tears`
- :mod:`alphalens.performance`
- :mod:`alphalens.plotting`
- :mod:`alphalens.utils`


