
Alphalens
=========

Tear Sheets
-----------

.. automodule:: alphalens.tears
    :members:
    :undoc-members:
    :show-inheritance:

Performance
-----------

.. automodule:: alphalens.performance
    :members:
    :undoc-members:
    :show-inheritance:

Plotting
--------

.. automodule:: alphalens.plotting
    :members:
    :undoc-members:
    :show-inheritance:

Utilities
---------

.. automodule:: alphalens.utils
    :members:
    :undoc-members:
    :show-inheritance:
